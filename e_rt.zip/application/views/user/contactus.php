<?php $this->load->view ("user/header") ?>
<!--banner-->
<div class="banner-top">
	<div class="container">
		<h1>Contact Us</h1>
		<em></em>
		<h2><a href="index.html">Home</a><label>/</label>Contact Us</a></h2>
	</div>
</div>	
		
			<div class="contact">
					
				<div class="contact-form">
					<div class="container">
					<div class="col-md-6 contact-left">
						<h3>Toko Lilac</h3>
						<p>Toko Lilac adalah toko yang berdiri pada tahun 2013.
						Toko ini menjual berbagai macam baju yang menarik dan trendy. </p>
					
			
					<div class="address">
					<div class=" address-grid">
							<i class="glyphicon glyphicon-camera"></i>
							<div class="address1">
								<h3>Instagram:</h3>
								<p>@lilacboutiquee</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class=" address-grid ">
							<i class="glyphicon glyphicon-phone"></i>
							<div class="address1">
							<h3>Our Phone:<h3>
								<p>+6281210441216</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class=" address-grid ">
							<i class="glyphicon glyphicon-envelope"></i>
							<div class="address1">
							<h3>Email:</h3>
								<p><a href="mailto:info@example.com"> lilacboutiquee@gmail.com</a></p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class=" address-grid ">
							<i class="glyphicon glyphicon-bell"></i>
							<div class="address1">
								<h3>Open Hours:</h3>
								<p>Monday-Friday, 7AM-5PM</p>
							</div>
							<div class="clearfix"> </div>
						</div>
</div>
				</div>
				<div class="col-md-6 contact-top">
					<h3>Leave Your Message Here</h3>
					<form action="" method="post">
						<div>
							<span>Your Name </span>		
							<input type="text" name="nama" >						
						</div>
						<div>
							<span>Your Email </span>		
							<input type="text" name="email" >						
						</div>
						<div>
							<span>Subject</span>		
							<input type="text" name="judul">	
						</div>
						<div>
							<span>Your Message</span>		
							<textarea name="pesan"> </textarea>	
						</div>
						<label class="hvr-skew-backward">
								<input type="submit" value="Send" >
						</label>
</form>						
				</div>
		<div class="clearfix"></div>
		</div>
		</div>
	</div>

<!--//contact-->
<?php $this->load->view ("user/footer") ?>