	<div class="footer">
	<div class="footer-middle">
				<div class="container">
					<div class="col-md-6 footer-middle-in">
						<a href="#"><img src="images/log.png" width='250px' alt=""></a>
						<p>Toko Lilac adalah toko yang berdiri pada tahun 2013.
						Toko ini menjual berbagai macam baju yang menarik dan trendy. </p>
					</div>
					
					<div class="col-md-3 footer-middle-in">
						<h6>Tags</h6>
						<ul class="tag-in">
							<li><a href="<?php echo base_url('index/product')?>">Women</a></li>
							<li><a href="<?php echo base_url('index/categories/1')?>">Dress</a></li>
							<li><a href="<?php echo base_url('index/categories/4')?>">Jumpsuit</a></li>
							<li><a href="<?php echo base_url('index/categories/2')?>">Pants</a></li>
							<li><a href="<?php echo base_url('index/categories/8')?>">Tank Top</a></li>
							<li><a href="<?php echo base_url('index/categories/3')?>">Top</a></li>
							<li><a href="<?php echo base_url('index/categories/6')?>">Skirt</a></li>
							<li><a href="<?php echo base_url('index/categories/7')?>">Blazer</a></li>
							<li><a href="<?php echo base_url('index/categories/2')?>">Cullote</a></li>
						</ul>
					</div>
					<div class="col-md-3 footer-middle-in">
						<h6>Payment</h6>
						<img src="images/atm.png" width="200" height="300" >
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
			<div class="footer-bottom">
				<div class="container">
					<p class="footer-class">&copy; 2016 TokoLilac. All Rights Reserved. </p>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
		<!--//footer-->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/simpleCart.min.js"> </script>
<!-- slide -->
<script src="js/bootstrap.min.js"></script>
<!--light-box-files -->
		<script src="js/jquery.chocolat.js"></script>
		<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="screen" charset="utf-8">
		<!--light-box-files -->
		<script type="text/javascript" charset="utf-8">
		$(function() {
			$('a.picture').Chocolat();
		});
		</script>


</body>
</html>