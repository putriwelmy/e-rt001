<!-- Footer -->
  <footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Copyright &copy; 2019 - Start Bootstrap</div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="<?php echo base_url("assets/user")?>/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url("assets/user")?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="<?php echo base_url("assets/user")?>/vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="<?php echo base_url("assets/user")?>/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="<?php echo base_url("assets/user")?>/js/creative.min.js"></script>

</body>

</html>
